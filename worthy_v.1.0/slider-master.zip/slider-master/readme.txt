﻿
        Start with any file in folder 'demos', 'examples'
        e.g. you can start with 'examples/simple-slider.source.html'.
        Use 'jssor.js' and 'jssor.slider.js' for development.
        Use 'jssor.slider.mini.js' (40KB for jQuery Plugin) or 'jssor.slider.min.js' (60KB for No-jQuery Version) for release.
        In addition you can run 'examples/simple-slider.compress.bat' to compress your slider to (minimum 17KB) code snippet, see 'examples/simple-slider.compress.bat'.
        Reference http://www.jssor.com/development/index.html


        Note that 'jssor.compress.exe' runs on windows system with .NET 2.0 installed.